# Love Letter 💌

An interactive web experience for confessing your feelings to someone special.

## What It Does

- A sealed envelope appears, waiting to be opened.
- Clicking the envelope reveals a heartfelt handwritten-style letter.
- After reading, the big question appears: **"Will you be mine?"**
- The **Yes** button triggers a romantic celebration with confetti.
- The **No** button keeps running away and the Yes button grows bigger — because love always finds a way. 😄

## How to Run

Simply open `index.html` in any modern web browser. No build tools or dependencies required.

## Files

| File        | Purpose                              |
|-------------|--------------------------------------|
| `index.html`| Page structure and content           |
| `style.css` | All styling and animations           |
| `script.js` | Interactivity and animations logic   |

## Customize

- Edit the letter text inside `.letter-body` in `index.html`.
- Change the color palette using the CSS variables in `:root` in `style.css`.
- Add your own name in the signature section.

Made with 💗 just for you.
